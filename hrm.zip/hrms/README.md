# HRMS — Multi-Subsidiary HR Management System

A Next.js (App Router) HR Management System for a company operating multiple
subsidiaries across countries/cities: org hierarchy, role-scoped dashboards,
and multi-level leave approvals with escalation.

Built against the assignment spec in Section 9 ("Assignment Scope &
Deliverables") of the SRS — this README documents what's fully working,
what's partially included, and what's deferred.

## Tech Stack

- **Framework:** Next.js 14, App Router, TypeScript, Server Components + Server Actions
- **Styling/UI:** Tailwind CSS + hand-rolled shadcn/ui-style primitives (Button, Input, Card, Table, Badge)
- **Charts:** Recharts (bar / pie / line — all reading live DB data, no mock arrays)
- **Database:** SQLite by default (zero-config, file-based) via **Prisma ORM**; swappable to MySQL by changing one line (see below)
- **Auth:** Custom email/password auth — bcrypt password hashing, JWT session in an httpOnly cookie (`jose`), role-based middleware route protection
- **Icons:** lucide-react

## Setup & Run (SQLite — default, no external DB needed)

```bash
npm install
cp .env.example .env          # generates .env with DATABASE_URL + JWT_SECRET
npm run db:push               # creates prisma/dev.db and applies the schema
npm run db:seed               # seeds countries/subsidiaries/employees/leave/demo users
npm run dev                   # http://localhost:3000
```

That's it — SQLite needs no server, no Docker, no credentials.

## Setup & Run (MySQL instead)

1. In `prisma/schema.prisma`, change:
   ```prisma
   datasource db {
     provider = "mysql"   // was "sqlite"
     url      = env("DATABASE_URL")
   }
   ```
2. In `.env`, set `DATABASE_URL="mysql://user:password@localhost:3306/hrms"`.
3. Run the same three commands: `npm install`, `npm run db:push`, `npm run db:seed`, `npm run dev`.

## Demo Login Credentials

Seeded by `prisma/seed.ts` — one account per required role:

| Role | Email | Password |
|---|---|---|
| Super Admin | `admin@hrms.com` | `Admin@123` |
| HR Manager | `hr@hrms.com` | `Hr@12345` |
| Manager | `manager@hrms.com` | `Manager@123` |
| Employee | `employee@hrms.com` | `Employee@123` |

The seed also creates a realistic 3-level reporting chain across 2 countries
(US, India) and 2 subsidiaries (Globex Americas / Globex India), 4
departments, ~12 employees, leave types with balances, and 3 sample leave
requests already sitting at different stages of the approval pipeline so the
dashboards and queues are populated immediately.

## What Was Completed (Section 9.1 — Mandatory)

- ✅ Auth with 3+ distinct roles (Super Admin, HR Manager, Manager, Employee), session-protected routes via middleware, role-scoped navigation
- ✅ Org data model: 2 countries, 2 subsidiaries, 4 departments, designations, ~12 seeded employees with a real multi-level reporting chain
- ✅ Leave management end-to-end: employee submits → routes to direct manager → auto-escalates to Department Head when duration exceeds the leave type's threshold → HR Manager can view/override → status visible on the employee's dashboard, with a full timestamped approval audit trail
- ✅ 3 role-based dashboards (Admin/global, HR/subsidiary, Manager/team) with Recharts visualizations reading live Prisma queries — no hard-coded arrays
- ✅ Organization chart: recursive tree view, global for Super Admin, subsidiary-scoped for other roles

## What Was Included (Section 9.2 — Should Include)

- ✅ Holiday calendar per subsidiary (view)
- ✅ Attendance: simplified daily status model + 14-day seeded history feeding an attendance-rate chart on the HR dashboard
- ⚠️ Notifications for leave status changes: the data model supports it (every status transition is already logged in `LeaveApproval`), but there is no in-app notification bell/UI yet — deferred due to the 2-day time-box.

## Deferred (Section 9.3 — Documented, Not Built)

**Payroll, Recruitment/ATS, Performance Management.** How the current schema
extends to each:

- **Payroll** — add a `PayrollRun` + `Payslip` model keyed to `Employee`, driven by `Designation`-level base pay and `Attendance`/`LeaveBalance` deductions already tracked.
- **Recruitment/ATS** — add `JobRequisition` (owned by `Department`) and `Candidate`/`Application` models; on hire, an `Application` converts into an `Employee` + `User`, reusing the existing onboarding path.
- **Performance Management** — add a `ReviewCycle` + `Review` model referencing the existing `manager`/`directReports` self-relation on `Employee`, since the reporting chain needed for review routing already exists.

## Not Yet Verified Locally

This project was generated in an offline sandbox without npm registry
access, so `npm install` / `next build` could not be executed here to
confirm a clean compile. The code follows standard, well-trodden Next.js
14 App Router + Prisma patterns throughout; if `npm run build` surfaces any
type or import error after `npm install`, they should be small and
mechanical (e.g. a missing type import) — check the terminal output first.

## Project Structure

```
prisma/schema.prisma      Data model (org hierarchy, users, leave workflow, attendance)
prisma/seed.ts            Seed data + demo users
src/lib/auth.ts           Password hashing, JWT session cookie
src/lib/rbac.ts           Role guards for Server Components
src/lib/leave.ts          Leave submission + multi-level approval/escalation state machine
src/middleware.ts         Route-level session + role enforcement
src/app/login             Login page + server action
src/app/admin             Super Admin: global dashboard, employee directory, org/dept management
src/app/hr                HR Manager: subsidiary dashboard, full leave register + override, holidays
src/app/manager           Manager: team dashboard, leave approvals queue
src/app/employee          Employee: personal dashboard, leave request form
src/app/org-chart         Shared recursive org chart (scoped by role)
src/components/ui         Tailwind/shadcn-style primitives (Button, Card, Table, Badge, Input)
src/components/charts     Recharts wrappers (bar, pie, line)
```

## Design/Implementation Notes

- **RBAC** is enforced twice: `middleware.ts` blocks cross-role route access
  at the edge, and each Server Component also calls `requireRole(...)`
  before querying data — so even a route that slipped past middleware can't
  return another role's data.
- **Leave escalation** is entity-driven, not hard-coded: each `LeaveType` has
  an `escalationDays` threshold; requests longer than that threshold above
  their leave type's simple manager sign-off automatically add a second
  `LeaveApproval` row at the Department Head level.
- **No paid third-party services** are required — SQLite needs zero setup,
  and there is no dependency on a licensed API key for core functionality.
