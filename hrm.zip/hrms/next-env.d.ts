/// <reference types="next" />
/// <reference types="next/image-types/global" />

// NOTE: This file should not be edited. It is generated automatically by `next dev`/`next build`.
