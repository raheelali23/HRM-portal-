import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function hash(pw: string) {
  return bcrypt.hash(pw, 10);
}

async function main() {
  console.log("Seeding database...");

  await prisma.company.create({ data: { name: "Globex International" } });

  // ---- Countries & Subsidiaries ----
  const usa = await prisma.country.create({ data: { name: "United States", code: "US" } });
  const india = await prisma.country.create({ data: { name: "India", code: "IN" } });

  const nySub = await prisma.subsidiary.create({
    data: { name: "Globex Americas", city: "New York", timezone: "America/New_York", currency: "USD", countryId: usa.id },
  });
  const blrSub = await prisma.subsidiary.create({
    data: { name: "Globex India", city: "Bengaluru", timezone: "Asia/Kolkata", currency: "INR", countryId: india.id },
  });

  // ---- Departments & Designations ----
  const nyEng = await prisma.department.create({ data: { name: "Engineering", subsidiaryId: nySub.id } });
  const nySales = await prisma.department.create({ data: { name: "Sales", subsidiaryId: nySub.id } });
  const blrEng = await prisma.department.create({ data: { name: "Engineering", subsidiaryId: blrSub.id } });
  const blrSupport = await prisma.department.create({ data: { name: "Support", subsidiaryId: blrSub.id } });

  const desig = async (title: string, departmentId: string) =>
    prisma.designation.create({ data: { title, departmentId } });

  const dNyVpEng = await desig("VP Engineering", nyEng.id);
  const dNyEngMgr = await desig("Engineering Manager", nyEng.id);
  const dNySwe = await desig("Software Engineer", nyEng.id);
  const dNySalesHead = await desig("Head of Sales", nySales.id);
  const dNySalesRep = await desig("Sales Representative", nySales.id);

  const dBlrDirEng = await desig("Director of Engineering", blrEng.id);
  const dBlrEngMgr = await desig("Engineering Manager", blrEng.id);
  const dBlrSwe = await desig("Software Engineer", blrEng.id);
  const dBlrSupportLead = await desig("Support Team Lead", blrSupport.id);
  const dBlrSupportAgent = await desig("Support Agent", blrSupport.id);

  // ---- Leave types (per subsidiary) ----
  const leaveTypeDefs = [
    { name: "Annual / Vacation Leave", escalationDays: 3, defaultAnnualDays: 18 },
    { name: "Sick Leave", escalationDays: 5, defaultAnnualDays: 10 },
    { name: "Casual Leave", escalationDays: 2, defaultAnnualDays: 8 },
    { name: "Unpaid Leave", escalationDays: 1, defaultAnnualDays: 0 },
    { name: "Maternity / Paternity Leave", escalationDays: 0, defaultAnnualDays: 90 },
    { name: "Bereavement Leave", escalationDays: 0, defaultAnnualDays: 5 },
    { name: "Work-from-Home / Remote Day", escalationDays: 30, defaultAnnualDays: 24 },
  ];
  const nyLeaveTypes = await Promise.all(
    leaveTypeDefs.map((lt) => prisma.leaveType.create({ data: { ...lt, subsidiaryId: nySub.id } }))
  );
  const blrLeaveTypes = await Promise.all(
    leaveTypeDefs.map((lt) => prisma.leaveType.create({ data: { ...lt, subsidiaryId: blrSub.id } }))
  );

  // ---- Holidays ----
  await prisma.holiday.createMany({
    data: [
      { subsidiaryId: nySub.id, date: new Date("2026-01-01"), name: "New Year's Day" },
      { subsidiaryId: nySub.id, date: new Date("2026-07-04"), name: "Independence Day" },
      { subsidiaryId: nySub.id, date: new Date("2026-12-25"), name: "Christmas Day" },
      { subsidiaryId: blrSub.id, date: new Date("2026-01-26"), name: "Republic Day" },
      { subsidiaryId: blrSub.id, date: new Date("2026-10-20"), name: "Diwali" },
      { subsidiaryId: blrSub.id, date: new Date("2026-08-15"), name: "Independence Day" },
    ],
  });

  // ---- Employees: New York Engineering chain (VP -> Eng Mgr -> 2 SWEs) ----
  const vpEng = await prisma.employee.create({
    data: {
      firstName: "Alicia", lastName: "Stone", email: "alicia.stone@globex.com",
      subsidiaryId: nySub.id, departmentId: nyEng.id, designationId: dNyVpEng.id,
      joiningDate: new Date("2019-03-01"),
    },
  });
  const nyEngMgr = await prisma.employee.create({
    data: {
      firstName: "Marcus", lastName: "Lee", email: "marcus.lee@globex.com",
      subsidiaryId: nySub.id, departmentId: nyEng.id, designationId: dNyEngMgr.id,
      managerId: vpEng.id, joiningDate: new Date("2020-06-15"),
    },
  });
  const nySwe1 = await prisma.employee.create({
    data: {
      firstName: "Priya", lastName: "Nair", email: "priya.nair@globex.com",
      subsidiaryId: nySub.id, departmentId: nyEng.id, designationId: dNySwe.id,
      managerId: nyEngMgr.id, joiningDate: new Date("2022-01-10"),
    },
  });
  const nySwe2 = await prisma.employee.create({
    data: {
      firstName: "Daniel", lastName: "Kim", email: "daniel.kim@globex.com",
      subsidiaryId: nySub.id, departmentId: nyEng.id, designationId: dNySwe.id,
      managerId: nyEngMgr.id, joiningDate: new Date("2023-04-22"),
    },
  });

  // ---- Employees: New York Sales ----
  const nySalesHead = await prisma.employee.create({
    data: {
      firstName: "Grace", lastName: "Turner", email: "grace.turner@globex.com",
      subsidiaryId: nySub.id, departmentId: nySales.id, designationId: dNySalesHead.id,
      managerId: vpEng.id, joiningDate: new Date("2020-09-01"),
    },
  });
  const nySalesRep = await prisma.employee.create({
    data: {
      firstName: "Omar", lastName: "Haddad", email: "omar.haddad@globex.com",
      subsidiaryId: nySub.id, departmentId: nySales.id, designationId: dNySalesRep.id,
      managerId: nySalesHead.id, joiningDate: new Date("2023-11-01"),
    },
  });

  // ---- Employees: Bengaluru Engineering (Director -> Eng Mgr -> 2 SWEs) ----
  const dirEng = await prisma.employee.create({
    data: {
      firstName: "Rohan", lastName: "Mehta", email: "rohan.mehta@globex.com",
      subsidiaryId: blrSub.id, departmentId: blrEng.id, designationId: dBlrDirEng.id,
      joiningDate: new Date("2018-05-10"),
    },
  });
  const blrEngMgr = await prisma.employee.create({
    data: {
      firstName: "Sneha", lastName: "Rao", email: "sneha.rao@globex.com",
      subsidiaryId: blrSub.id, departmentId: blrEng.id, designationId: dBlrEngMgr.id,
      managerId: dirEng.id, joiningDate: new Date("2020-02-18"),
    },
  });
  const blrSwe1 = await prisma.employee.create({
    data: {
      firstName: "Arjun", lastName: "Verma", email: "arjun.verma@globex.com",
      subsidiaryId: blrSub.id, departmentId: blrEng.id, designationId: dBlrSwe.id,
      managerId: blrEngMgr.id, joiningDate: new Date("2022-07-04"),
    },
  });
  const blrSwe2 = await prisma.employee.create({
    data: {
      firstName: "Kavya", lastName: "Iyer", email: "kavya.iyer@globex.com",
      subsidiaryId: blrSub.id, departmentId: blrEng.id, designationId: dBlrSwe.id,
      managerId: blrEngMgr.id, joiningDate: new Date("2023-09-12"),
    },
  });

  // ---- Employees: Bengaluru Support ----
  const supportLead = await prisma.employee.create({
    data: {
      firstName: "Neha", lastName: "Kapoor", email: "neha.kapoor@globex.com",
      subsidiaryId: blrSub.id, departmentId: blrSupport.id, designationId: dBlrSupportLead.id,
      managerId: dirEng.id, joiningDate: new Date("2021-01-20"),
    },
  });
  const supportAgent = await prisma.employee.create({
    data: {
      firstName: "Vikram", lastName: "Das", email: "vikram.das@globex.com",
      subsidiaryId: blrSub.id, departmentId: blrSupport.id, designationId: dBlrSupportAgent.id,
      managerId: supportLead.id, joiningDate: new Date("2024-02-01"),
    },
  });

  // ---- Leave balances for every employee, every leave type in their subsidiary ----
  const allEmployees = [vpEng, nyEngMgr, nySwe1, nySwe2, nySalesHead, nySalesRep, dirEng, blrEngMgr, blrSwe1, blrSwe2, supportLead, supportAgent];
  for (const emp of allEmployees) {
    const types = emp.subsidiaryId === nySub.id ? nyLeaveTypes : blrLeaveTypes;
    for (const lt of types) {
      await prisma.leaveBalance.create({
        data: { employeeId: emp.id, leaveTypeId: lt.id, balanceDays: lt.defaultAnnualDays },
      });
    }
  }

  // ---- Demo login users: one per required role ----
  await prisma.user.create({
    data: { email: "admin@hrms.com", passwordHash: await hash("Admin@123"), role: "SUPER_ADMIN" },
  });
  await prisma.user.create({
    data: {
      email: "hr@hrms.com", passwordHash: await hash("Hr@12345"), role: "HR_MANAGER",
      employeeId: dirEng.id, // acting HR manager for Globex India, also demonstrates HR-scoped views
    },
  });
  await prisma.user.create({
    data: { email: "manager@hrms.com", passwordHash: await hash("Manager@123"), role: "MANAGER", employeeId: nyEngMgr.id },
  });
  await prisma.user.create({
    data: { email: "employee@hrms.com", passwordHash: await hash("Employee@123"), role: "EMPLOYEE", employeeId: nySwe1.id },
  });

  // ---- Sample leave requests to populate dashboards/queues out of the box ----
  const annualNY = nyLeaveTypes.find((l) => l.name === "Annual / Vacation Leave")!;
  const sickNY = nyLeaveTypes.find((l) => l.name === "Sick Leave")!;

  await prisma.leaveRequest.create({
    data: {
      employeeId: nySwe1.id, leaveTypeId: sickNY.id,
      startDate: new Date("2026-09-15"), endDate: new Date("2026-09-16"), days: 2,
      reason: "Flu", status: "PENDING_MANAGER",
      approvals: { create: [{ approverId: nyEngMgr.id, level: "MANAGER", decision: "PENDING" }] },
    },
  });

  await prisma.leaveRequest.create({
    data: {
      employeeId: nySwe2.id, leaveTypeId: annualNY.id,
      startDate: new Date("2026-10-01"), endDate: new Date("2026-10-06"), days: 6,
      reason: "Family trip", status: "PENDING_DEPT_HEAD",
      approvals: {
        create: [
          { approverId: nyEngMgr.id, level: "MANAGER", decision: "APPROVED", decidedAt: new Date("2026-09-05"), comment: "Enjoy!" },
          { approverId: vpEng.id, level: "DEPT_HEAD", decision: "PENDING" },
        ],
      },
    },
  });

  await prisma.leaveRequest.create({
    data: {
      employeeId: nySwe1.id, leaveTypeId: annualNY.id,
      startDate: new Date("2026-08-10"), endDate: new Date("2026-08-11"), days: 2,
      reason: "Personal", status: "APPROVED",
      approvals: {
        create: [{ approverId: nyEngMgr.id, level: "MANAGER", decision: "APPROVED", decidedAt: new Date("2026-08-01") }],
      },
    },
  });

  // ---- Announcements ----
  await prisma.announcement.create({
    data: { title: "Welcome to the new HRMS", body: "This portal now hosts leave, org charts, and dashboards.", scope: "GLOBAL" },
  });
  await prisma.announcement.create({
    data: { title: "Diwali office closure", body: "Globex India office will be closed on Oct 20 for Diwali.", scope: "SUBSIDIARY", subsidiaryId: blrSub.id },
  });

  // ---- Attendance: seed a rolling 14-day window for a couple of employees ----
  const today = new Date();
  for (let i = 13; i >= 0; i--) {
    const day = new Date(today);
    day.setDate(day.getDate() - i);
    const isWeekend = day.getDay() === 0 || day.getDay() === 6;
    for (const emp of [nySwe1, nySwe2, blrSwe1, blrSwe2]) {
      await prisma.attendance.create({
        data: {
          employeeId: emp.id,
          date: day,
          status: isWeekend ? "WEEKEND" : Math.random() > 0.12 ? "PRESENT" : "ABSENT",
        },
      });
    }
  }

  console.log("Seed complete.");
  console.log("Demo logins:");
  console.log("  Super Admin -> admin@hrms.com / Admin@123");
  console.log("  HR Manager  -> hr@hrms.com / Hr@12345");
  console.log("  Manager     -> manager@hrms.com / Manager@123");
  console.log("  Employee    -> employee@hrms.com / Employee@123");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
