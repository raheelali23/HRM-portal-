import { prisma } from "@/lib/prisma";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, THead, TBody, TR, TH, TD } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

export default async function EmployeeDirectory({
  searchParams,
}: {
  searchParams: { q?: string; subsidiary?: string; status?: string };
}) {
  const [employees, subsidiaries] = await Promise.all([
    prisma.employee.findMany({
      where: {
        AND: [
          searchParams.q
            ? {
                OR: [
                  { firstName: { contains: searchParams.q } },
                  { lastName: { contains: searchParams.q } },
                  { email: { contains: searchParams.q } },
                ],
              }
            : {},
          searchParams.subsidiary ? { subsidiaryId: searchParams.subsidiary } : {},
          searchParams.status ? { status: searchParams.status as any } : {},
        ],
      },
      include: { subsidiary: true, department: true, designation: true, manager: true },
      orderBy: { firstName: "asc" },
    }),
    prisma.subsidiary.findMany(),
  ]);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold">Employee Directory</h1>
        <p className="text-sm text-muted-foreground">{employees.length} employees found</p>
      </div>

      <Card>
        <CardHeader><CardTitle>Filters</CardTitle></CardHeader>
        <CardContent>
          <form className="flex flex-wrap gap-2" method="get">
            <input
              name="q"
              defaultValue={searchParams.q}
              placeholder="Search name or email..."
              className="h-9 rounded-md border border-border px-3 text-sm"
            />
            <select name="subsidiary" defaultValue={searchParams.subsidiary} className="h-9 rounded-md border border-border px-2 text-sm">
              <option value="">All subsidiaries</option>
              {subsidiaries.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
            <select name="status" defaultValue={searchParams.status} className="h-9 rounded-md border border-border px-2 text-sm">
              <option value="">All statuses</option>
              <option value="ACTIVE">Active</option>
              <option value="ON_LEAVE">On Leave</option>
              <option value="TERMINATED">Terminated</option>
            </select>
            <button className="h-9 rounded-md bg-primary px-4 text-sm text-primary-foreground">Apply</button>
          </form>
        </CardContent>
      </Card>

      <Table>
        <THead>
          <TR>
            <TH>Name</TH><TH>Subsidiary</TH><TH>Department</TH><TH>Designation</TH><TH>Manager</TH><TH>Status</TH>
          </TR>
        </THead>
        <TBody>
          {employees.map((e) => (
            <TR key={e.id}>
              <TD className="font-medium">{e.firstName} {e.lastName}<div className="text-xs text-muted-foreground">{e.email}</div></TD>
              <TD>{e.subsidiary.name}</TD>
              <TD>{e.department.name}</TD>
              <TD>{e.designation.title}</TD>
              <TD>{e.manager ? `${e.manager.firstName} ${e.manager.lastName}` : "—"}</TD>
              <TD>
                <Badge variant={e.status === "ACTIVE" ? "success" : e.status === "ON_LEAVE" ? "warning" : "destructive"}>
                  {e.status}
                </Badge>
              </TD>
            </TR>
          ))}
        </TBody>
      </Table>
    </div>
  );
}
