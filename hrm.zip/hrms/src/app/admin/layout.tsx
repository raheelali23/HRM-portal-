import { requireRole } from "@/lib/rbac";
import { SidebarNav } from "@/components/sidebar-nav";

const NAV = [
  { href: "/admin", label: "Dashboard", icon: "dashboard" as const },
  { href: "/admin/employees", label: "Employees", icon: "employees" as const },
  { href: "/admin/organization", label: "Subsidiaries & Depts", icon: "org" as const },
  { href: "/org-chart", label: "Org Chart", icon: "chart" as const },
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await requireRole(["SUPER_ADMIN"]);
  return (
    <div className="flex">
      <SidebarNav items={NAV} roleLabel="Super Admin" userName={session.email} />
      <main className="flex-1 p-6">{children}</main>
    </div>
  );
}
