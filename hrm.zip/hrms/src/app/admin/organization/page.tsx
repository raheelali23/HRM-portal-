import { prisma } from "@/lib/prisma";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default async function OrganizationPage() {
  const subsidiaries = await prisma.subsidiary.findMany({
    include: {
      country: true,
      departments: { include: { designations: true, _count: { select: { employees: true } } } },
    },
  });

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold">Subsidiaries & Departments</h1>
        <p className="text-sm text-muted-foreground">
          Super Admin can create/edit/deactivate subsidiaries and countries. Subsidiary HR Managers manage
          departments and designations within their own subsidiary.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {subsidiaries.map((s) => (
          <Card key={s.id}>
            <CardHeader>
              <CardTitle className="text-base text-foreground">{s.name}</CardTitle>
              <p className="text-xs text-muted-foreground">{s.city}, {s.country.name} · {s.timezone} · {s.currency}</p>
            </CardHeader>
            <CardContent className="space-y-3">
              {s.departments.map((d) => (
                <div key={d.id} className="rounded-md border border-border p-3">
                  <div className="flex items-center justify-between">
                    <p className="font-medium">{d.name}</p>
                    <span className="text-xs text-muted-foreground">{d._count.employees} employees</span>
                  </div>
                  <div className="mt-1 flex flex-wrap gap-1">
                    {d.designations.map((desig) => (
                      <span key={desig.id} className="rounded-full bg-secondary px-2 py-0.5 text-xs">{desig.title}</span>
                    ))}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
