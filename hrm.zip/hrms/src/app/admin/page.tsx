import { prisma } from "@/lib/prisma";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { HeadcountBarChart } from "@/components/charts/headcount-bar-chart";
import { LeaveStatusPie } from "@/components/charts/leave-status-pie";

export default async function AdminDashboard() {
  const [subsidiaries, employeeCount, pendingLeave, leaveByStatus] = await Promise.all([
    prisma.subsidiary.findMany({ include: { _count: { select: { employees: true } }, country: true } }),
    prisma.employee.count({ where: { status: "ACTIVE" } }),
    prisma.leaveRequest.count({ where: { status: { in: ["PENDING_MANAGER", "PENDING_DEPT_HEAD", "PENDING_HR"] } } }),
    prisma.leaveRequest.groupBy({ by: ["status"], _count: { status: true } }),
  ]);

  const headcountData = subsidiaries.map((s) => ({ name: `${s.name} (${s.country.code})`, count: s._count.employees }));
  const leavePieData = leaveByStatus.map((row) => ({ name: row.status, value: row._count.status }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Global Overview</h1>
        <p className="text-sm text-muted-foreground">Consolidated view across all subsidiaries</p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card>
          <CardHeader><CardTitle>Active Employees</CardTitle></CardHeader>
          <CardContent><p className="text-3xl font-semibold">{employeeCount}</p></CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Subsidiaries</CardTitle></CardHeader>
          <CardContent><p className="text-3xl font-semibold">{subsidiaries.length}</p></CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Pending Leave Requests</CardTitle></CardHeader>
          <CardContent><p className="text-3xl font-semibold">{pendingLeave}</p></CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Headcount by Subsidiary</CardTitle></CardHeader>
          <CardContent><HeadcountBarChart data={headcountData} /></CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Leave Requests by Status</CardTitle></CardHeader>
          <CardContent>
            {leavePieData.length ? <LeaveStatusPie data={leavePieData} /> : <p className="text-sm text-muted-foreground">No leave requests yet.</p>}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle>Subsidiaries</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          {subsidiaries.map((s) => (
            <div key={s.id} className="flex items-center justify-between border-b border-border py-2 text-sm last:border-0">
              <span className="font-medium">{s.name}</span>
              <span className="text-muted-foreground">{s.city}, {s.country.name}</span>
              <span className="text-muted-foreground">{s._count.employees} employees</span>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
