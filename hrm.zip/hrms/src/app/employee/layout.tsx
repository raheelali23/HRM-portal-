import { requireRole } from "@/lib/rbac";
import { SidebarNav } from "@/components/sidebar-nav";
import { prisma } from "@/lib/prisma";

const NAV = [
  { href: "/employee", label: "Dashboard", icon: "dashboard" as const },
  { href: "/employee/leave/new", label: "Request Leave", icon: "leave" as const },
  { href: "/org-chart", label: "Org Chart", icon: "chart" as const },
];

export default async function EmployeeLayout({ children }: { children: React.ReactNode }) {
  const session = await requireRole(["EMPLOYEE", "SUPER_ADMIN"]);
  const employee = session.employeeId
    ? await prisma.employee.findUnique({ where: { id: session.employeeId } })
    : null;
  return (
    <div className="flex">
      <SidebarNav items={NAV} roleLabel="Employee" userName={employee ? `${employee.firstName} ${employee.lastName}` : session.email} />
      <main className="flex-1 p-6">{children}</main>
    </div>
  );
}
