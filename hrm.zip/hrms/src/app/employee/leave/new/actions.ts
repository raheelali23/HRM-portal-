"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireRole } from "@/lib/rbac";
import { submitLeaveRequest } from "@/lib/leave";

export type LeaveFormState = { error?: string };

export async function submitLeaveAction(_prev: LeaveFormState, formData: FormData): Promise<LeaveFormState> {
  const session = await requireRole(["EMPLOYEE", "SUPER_ADMIN"]);
  if (!session.employeeId) return { error: "No employee profile linked to this account." };

  const leaveTypeId = String(formData.get("leaveTypeId") ?? "");
  const startDate = new Date(String(formData.get("startDate") ?? ""));
  const endDate = new Date(String(formData.get("endDate") ?? ""));
  const reason = String(formData.get("reason") ?? "").trim();

  if (!leaveTypeId || isNaN(startDate.getTime()) || isNaN(endDate.getTime()) || !reason) {
    return { error: "Please fill in all fields." };
  }
  if (endDate < startDate) return { error: "End date must be on or after the start date." };

  try {
    await submitLeaveRequest({ employeeId: session.employeeId, leaveTypeId, startDate, endDate, reason });
  } catch (e: any) {
    return { error: e.message ?? "Failed to submit leave request." };
  }

  revalidatePath("/employee");
  redirect("/employee");
}
