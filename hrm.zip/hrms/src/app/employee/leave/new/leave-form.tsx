"use client";
import { useFormState, useFormStatus } from "react-dom";
import { submitLeaveAction, type LeaveFormState } from "./actions";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

const initialState: LeaveFormState = {};

function SubmitButton() {
  const { pending } = useFormStatus();
  return <Button type="submit" disabled={pending}>{pending ? "Submitting..." : "Submit Request"}</Button>;
}

export function LeaveForm({ leaveTypes }: { leaveTypes: { id: string; name: string }[] }) {
  const [state, formAction] = useFormState(submitLeaveAction, initialState);
  return (
    <form action={formAction} className="max-w-md space-y-4">
      <div className="space-y-1.5">
        <Label htmlFor="leaveTypeId">Leave Type</Label>
        <select id="leaveTypeId" name="leaveTypeId" required className="h-9 w-full rounded-md border border-border px-3 text-sm">
          <option value="">Select a leave type</option>
          {leaveTypes.map((lt) => <option key={lt.id} value={lt.id}>{lt.name}</option>)}
        </select>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label htmlFor="startDate">Start Date</Label>
          <Input id="startDate" name="startDate" type="date" required />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="endDate">End Date</Label>
          <Input id="endDate" name="endDate" type="date" required />
        </div>
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="reason">Reason</Label>
        <textarea id="reason" name="reason" required rows={3} className="w-full rounded-md border border-border px-3 py-2 text-sm" />
      </div>
      {state?.error && <p className="text-sm text-destructive">{state.error}</p>}
      <SubmitButton />
    </form>
  );
}
