import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LeaveForm } from "./leave-form";

export default async function NewLeaveRequestPage() {
  const session = await requireRole(["EMPLOYEE", "SUPER_ADMIN"]);
  const employee = session.employeeId
    ? await prisma.employee.findUnique({ where: { id: session.employeeId } })
    : null;
  const leaveTypes = employee
    ? await prisma.leaveType.findMany({ where: { subsidiaryId: employee.subsidiaryId } })
    : [];

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold">Request Leave</h1>
        <p className="text-sm text-muted-foreground">Your request routes to your direct manager first.</p>
      </div>
      <Card>
        <CardHeader><CardTitle>New request</CardTitle></CardHeader>
        <CardContent>
          <LeaveForm leaveTypes={leaveTypes} />
        </CardContent>
      </Card>
    </div>
  );
}
