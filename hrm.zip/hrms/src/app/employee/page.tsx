import { prisma } from "@/lib/prisma";
import { requireRole } from "@/lib/rbac";
import { redirect } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, THead, TBody, TR, TH, TD } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const STATUS_VARIANT: Record<string, "warning" | "success" | "destructive"> = {
  PENDING_MANAGER: "warning",
  PENDING_DEPT_HEAD: "warning",
  PENDING_HR: "warning",
  APPROVED: "success",
  REJECTED: "destructive",
};

export default async function EmployeeDashboard() {
  const session = await requireRole(["EMPLOYEE", "SUPER_ADMIN"]);
  if (!session.employeeId) redirect("/admin");

  const [employee, balances, requests, announcements] = await Promise.all([
    prisma.employee.findUnique({
      where: { id: session.employeeId },
      include: { manager: true, department: true, subsidiary: true, designation: true },
    }),
    prisma.leaveBalance.findMany({ where: { employeeId: session.employeeId }, include: { leaveType: true } }),
    prisma.leaveRequest.findMany({
      where: { employeeId: session.employeeId },
      include: { leaveType: true, approvals: { include: { approver: true } } },
      orderBy: { createdAt: "desc" },
    }),
    prisma.announcement.findMany({ orderBy: { createdAt: "desc" }, take: 5 }),
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Welcome, {employee?.firstName}</h1>
        <p className="text-sm text-muted-foreground">
          {employee?.designation.title} · {employee?.department.name} · {employee?.subsidiary.name}
          {employee?.manager && <> · Reports to {employee.manager.firstName} {employee.manager.lastName}</>}
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Leave Balances</CardTitle></CardHeader>
          <CardContent className="space-y-1">
            {balances.map((b) => (
              <div key={b.id} className="flex justify-between text-sm">
                <span>{b.leaveType.name}</span>
                <span className="font-medium">{b.balanceDays} days</span>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Announcements</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {announcements.map((a) => (
              <div key={a.id} className="text-sm">
                <p className="font-medium">{a.title}</p>
                <p className="text-xs text-muted-foreground">{a.body}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle>My Leave Requests</CardTitle></CardHeader>
        <CardContent>
          <Table>
            <THead>
              <TR><TH>Type</TH><TH>Dates</TH><TH>Days</TH><TH>Status</TH><TH>Current Approver</TH></TR>
            </THead>
            <TBody>
              {requests.map((r) => {
                const pending = r.approvals.find((a) => a.decision === "PENDING");
                return (
                  <TR key={r.id}>
                    <TD>{r.leaveType.name}</TD>
                    <TD>{r.startDate.toDateString()} – {r.endDate.toDateString()}</TD>
                    <TD>{r.days}</TD>
                    <TD><Badge variant={STATUS_VARIANT[r.status]}>{r.status.replace(/_/g, " ")}</Badge></TD>
                    <TD>{pending ? `${pending.approver.firstName} ${pending.approver.lastName}` : "—"}</TD>
                  </TR>
                );
              })}
              {requests.length === 0 && (
                <TR><TD colSpan={5} className="text-center text-muted-foreground">No leave requests yet.</TD></TR>
              )}
            </TBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
