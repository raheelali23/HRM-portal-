"use server";
import { revalidatePath } from "next/cache";
import { requireRole } from "@/lib/rbac";
import { hrOverrideLeaveDecision } from "@/lib/leave";

export async function hrOverrideAction(formData: FormData) {
  const session = await requireRole(["HR_MANAGER", "SUPER_ADMIN"]);
  if (!session.employeeId) throw new Error("No employee profile linked to this account.");

  const leaveRequestId = String(formData.get("leaveRequestId"));
  const decision = String(formData.get("decision")) as "APPROVED" | "REJECTED";
  const comment = String(formData.get("comment") ?? "HR policy override");

  await hrOverrideLeaveDecision({ leaveRequestId, hrEmployeeId: session.employeeId, decision, comment });
  revalidatePath("/hr/approvals");
  revalidatePath("/hr");
}
