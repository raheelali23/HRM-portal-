import { requireRole } from "@/lib/rbac";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, THead, TBody, TR, TH, TD } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { hrOverrideAction } from "./actions";

const STATUS_VARIANT: Record<string, "warning" | "success" | "destructive"> = {
  PENDING_MANAGER: "warning", PENDING_DEPT_HEAD: "warning", PENDING_HR: "warning",
  APPROVED: "success", REJECTED: "destructive",
};

export default async function HrAllLeavePage() {
  const session = await requireRole(["HR_MANAGER", "SUPER_ADMIN"]);
  if (!session.employeeId) redirect("/admin");

  const hrEmployee = await prisma.employee.findUniqueOrThrow({ where: { id: session.employeeId } });

  const requests = await prisma.leaveRequest.findMany({
    where: { employee: { subsidiaryId: hrEmployee.subsidiaryId } },
    include: { employee: true, leaveType: true, approvals: { include: { approver: true }, orderBy: { createdAt: "asc" } } },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold">All Leave Requests — Subsidiary</h1>
        <p className="text-sm text-muted-foreground">
          HR Manager can view every request in the subsidiary and, in policy-defined exception cases, override any decision.
        </p>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <THead>
              <TR><TH>Employee</TH><TH>Type</TH><TH>Dates</TH><TH>Status</TH><TH>Trail</TH><TH>HR Override</TH></TR>
            </THead>
            <TBody>
              {requests.map((r) => (
                <TR key={r.id}>
                  <TD>{r.employee.firstName} {r.employee.lastName}</TD>
                  <TD>{r.leaveType.name}</TD>
                  <TD className="whitespace-nowrap">{r.startDate.toDateString()} – {r.endDate.toDateString()}</TD>
                  <TD><Badge variant={STATUS_VARIANT[r.status]}>{r.status.replace(/_/g, " ")}</Badge></TD>
                  <TD className="text-xs text-muted-foreground">
                    {r.approvals.map((a) => (
                      <div key={a.id}>{a.level}: {a.approver.firstName} — {a.decision}{a.comment ? ` (${a.comment})` : ""}</div>
                    ))}
                  </TD>
                  <TD>
                    {r.status !== "APPROVED" && r.status !== "REJECTED" ? (
                      <form action={hrOverrideAction} className="flex gap-1">
                        <input type="hidden" name="leaveRequestId" value={r.id} />
                        <Button size="sm" name="decision" value="APPROVED" type="submit">Approve</Button>
                        <Button size="sm" variant="destructive" name="decision" value="REJECTED" type="submit">Reject</Button>
                      </form>
                    ) : (
                      <span className="text-xs text-muted-foreground">Final</span>
                    )}
                  </TD>
                </TR>
              ))}
            </TBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
