import { requireRole } from "@/lib/rbac";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default async function HolidayCalendarPage() {
  const session = await requireRole(["HR_MANAGER", "SUPER_ADMIN"]);
  if (!session.employeeId) redirect("/admin");

  const hrEmployee = await prisma.employee.findUniqueOrThrow({ where: { id: session.employeeId } });
  const holidays = await prisma.holiday.findMany({
    where: { subsidiaryId: hrEmployee.subsidiaryId },
    orderBy: { date: "asc" },
  });

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold">Holiday Calendar</h1>
        <p className="text-sm text-muted-foreground">
          Public holidays for your subsidiary. These are excluded automatically from leave-day calculations.
        </p>
      </div>
      <Card>
        <CardHeader><CardTitle>Upcoming & recorded holidays</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          {holidays.map((h) => (
            <div key={h.id} className="flex justify-between border-b border-border py-2 text-sm last:border-0">
              <span>{h.name}</span>
              <span className="text-muted-foreground">{h.date.toDateString()}</span>
            </div>
          ))}
          {holidays.length === 0 && <p className="text-sm text-muted-foreground">No holidays configured yet.</p>}
        </CardContent>
      </Card>
    </div>
  );
}
