import { requireRole } from "@/lib/rbac";
import { SidebarNav } from "@/components/sidebar-nav";
import { prisma } from "@/lib/prisma";

const NAV = [
  { href: "/hr", label: "Dashboard", icon: "dashboard" as const },
  { href: "/hr/approvals", label: "Leave (All Requests)", icon: "approvals" as const },
  { href: "/hr/holidays", label: "Holiday Calendar", icon: "calendar" as const },
  { href: "/org-chart", label: "Org Chart", icon: "chart" as const },
];

export default async function HrLayout({ children }: { children: React.ReactNode }) {
  const session = await requireRole(["HR_MANAGER", "SUPER_ADMIN"]);
  const employee = session.employeeId
    ? await prisma.employee.findUnique({ where: { id: session.employeeId } })
    : null;
  return (
    <div className="flex">
      <SidebarNav items={NAV} roleLabel="HR Manager" userName={employee ? `${employee.firstName} ${employee.lastName}` : session.email} />
      <main className="flex-1 p-6">{children}</main>
    </div>
  );
}
