import { requireRole } from "@/lib/rbac";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { HeadcountBarChart } from "@/components/charts/headcount-bar-chart";
import { AttendanceLineChart } from "@/components/charts/attendance-line-chart";

export default async function HrDashboard() {
  const session = await requireRole(["HR_MANAGER", "SUPER_ADMIN"]);
  if (!session.employeeId) redirect("/admin");

  const hrEmployee = await prisma.employee.findUniqueOrThrow({ where: { id: session.employeeId } });
  const subsidiaryId = hrEmployee.subsidiaryId;

  const [subsidiary, departments, pendingLeave, recentLeave, attendanceRows] = await Promise.all([
    prisma.subsidiary.findUniqueOrThrow({ where: { id: subsidiaryId }, include: { country: true } }),
    prisma.department.findMany({ where: { subsidiaryId }, include: { _count: { select: { employees: true } } } }),
    prisma.leaveRequest.count({
      where: { employee: { subsidiaryId }, status: { in: ["PENDING_MANAGER", "PENDING_DEPT_HEAD", "PENDING_HR"] } },
    }),
    prisma.leaveRequest.findMany({
      where: { employee: { subsidiaryId } },
      include: { employee: true, leaveType: true },
      orderBy: { createdAt: "desc" },
      take: 8,
    }),
    prisma.attendance.findMany({ where: { employee: { subsidiaryId } }, orderBy: { date: "asc" } }),
  ]);

  const deptChartData = departments.map((d) => ({ name: d.name, count: d._count.employees }));

  const byDate: Record<string, { present: number; total: number }> = {};
  for (const row of attendanceRows) {
    const key = row.date.toISOString().slice(0, 10);
    byDate[key] ??= { present: 0, total: 0 };
    if (row.status !== "WEEKEND") {
      byDate[key].total += 1;
      if (row.status === "PRESENT") byDate[key].present += 1;
    }
  }
  const attendanceData = Object.entries(byDate)
    .filter(([, v]) => v.total > 0)
    .map(([date, v]) => ({ date: date.slice(5), presentRate: Math.round((v.present / v.total) * 100) }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">{subsidiary.name} — HR Overview</h1>
        <p className="text-sm text-muted-foreground">{subsidiary.city}, {subsidiary.country.name}</p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Card>
          <CardHeader><CardTitle>Departments</CardTitle></CardHeader>
          <CardContent><p className="text-3xl font-semibold">{departments.length}</p></CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Employees</CardTitle></CardHeader>
          <CardContent><p className="text-3xl font-semibold">{departments.reduce((sum, d) => sum + d._count.employees, 0)}</p></CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Pending Leave</CardTitle></CardHeader>
          <CardContent><p className="text-3xl font-semibold">{pendingLeave}</p></CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Headcount by Department</CardTitle></CardHeader>
          <CardContent><HeadcountBarChart data={deptChartData} /></CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Attendance Rate (last 14 days)</CardTitle></CardHeader>
          <CardContent>
            {attendanceData.length ? <AttendanceLineChart data={attendanceData} /> : <p className="text-sm text-muted-foreground">No attendance data.</p>}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle>Recent Leave Requests (Subsidiary-wide)</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          {recentLeave.map((r) => (
            <div key={r.id} className="flex justify-between text-sm">
              <span>{r.employee.firstName} {r.employee.lastName} — {r.leaveType.name}</span>
              <span className="text-muted-foreground">{r.status.replace(/_/g, " ")}</span>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
