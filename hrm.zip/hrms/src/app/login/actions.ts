"use server";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { verifyPassword, createSession } from "@/lib/auth";
import { roleHome } from "@/lib/rbac";

export type LoginState = { error?: string };

export async function loginAction(_prev: LoginState, formData: FormData): Promise<LoginState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");

  if (!email || !password) return { error: "Email and password are required." };

  const user = await prisma.user.findUnique({ where: { email }, include: { employee: true } });
  if (!user) return { error: "Invalid email or password." };

  const valid = await verifyPassword(password, user.passwordHash);
  if (!valid) return { error: "Invalid email or password." };

  await createSession({
    userId: user.id,
    employeeId: user.employeeId,
    role: user.role,
    email: user.email,
    name: user.employee ? `${user.employee.firstName} ${user.employee.lastName}` : "Super Admin",
  });

  redirect(roleHome(user.role));
}
