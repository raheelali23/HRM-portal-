import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LoginForm } from "./login-form";

const DEMO_ACCOUNTS = [
  { role: "Super Admin", email: "admin@hrms.com", password: "Admin@123" },
  { role: "HR Manager", email: "hr@hrms.com", password: "Hr@12345" },
  { role: "Manager", email: "manager@hrms.com", password: "Manager@123" },
  { role: "Employee", email: "employee@hrms.com", password: "Employee@123" },
];

export default function LoginPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-secondary/40 p-4">
      <div className="w-full max-w-md space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg text-foreground">Sign in to HRMS</CardTitle>
          </CardHeader>
          <CardContent>
            <LoginForm />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Demo accounts</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1 text-xs text-muted-foreground">
            {DEMO_ACCOUNTS.map((a) => (
              <div key={a.email} className="flex justify-between">
                <span>{a.role}</span>
                <span className="font-mono">{a.email} / {a.password}</span>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
