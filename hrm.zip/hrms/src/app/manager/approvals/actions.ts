"use server";
import { revalidatePath } from "next/cache";
import { requireRole } from "@/lib/rbac";
import { decideLeaveApproval } from "@/lib/leave";

export async function decideApprovalAction(formData: FormData) {
  const session = await requireRole(["MANAGER", "SUPER_ADMIN"]);
  if (!session.employeeId) throw new Error("No employee profile linked to this account.");

  const leaveRequestId = String(formData.get("leaveRequestId"));
  const decision = String(formData.get("decision")) as "APPROVED" | "REJECTED";
  const comment = String(formData.get("comment") ?? "");

  await decideLeaveApproval({ leaveRequestId, approverEmployeeId: session.employeeId, decision, comment });
  revalidatePath("/manager/approvals");
  revalidatePath("/manager");
}
