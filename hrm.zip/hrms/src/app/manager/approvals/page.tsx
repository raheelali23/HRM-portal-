import { requireRole } from "@/lib/rbac";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { decideApprovalAction } from "./actions";

export default async function ApprovalsQueuePage() {
  const session = await requireRole(["MANAGER", "SUPER_ADMIN"]);
  if (!session.employeeId) redirect("/admin");

  const pendingApprovals = await prisma.leaveApproval.findMany({
    where: { approverId: session.employeeId, decision: "PENDING" },
    include: { leaveRequest: { include: { employee: true, leaveType: true } } },
    orderBy: { createdAt: "asc" },
  });

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold">Leave Approvals</h1>
        <p className="text-sm text-muted-foreground">{pendingApprovals.length} request(s) awaiting your decision</p>
      </div>

      <div className="space-y-3">
        {pendingApprovals.map((approval) => {
          const r = approval.leaveRequest;
          return (
            <Card key={approval.id}>
              <CardHeader>
                <CardTitle className="text-base text-foreground">
                  {r.employee.firstName} {r.employee.lastName} — {r.leaveType.name}
                </CardTitle>
                <p className="text-xs text-muted-foreground">
                  {r.startDate.toDateString()} – {r.endDate.toDateString()} ({r.days} day{r.days > 1 ? "s" : ""})
                  · Approval level: {approval.level.replace("_", " ")}
                </p>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm">{r.reason}</p>
                <form action={decideApprovalAction} className="flex flex-wrap items-center gap-2">
                  <input type="hidden" name="leaveRequestId" value={r.id} />
                  <input
                    name="comment"
                    placeholder="Optional comment"
                    className="h-9 flex-1 min-w-[160px] rounded-md border border-border px-3 text-sm"
                  />
                  <Button name="decision" value="APPROVED" type="submit">Approve</Button>
                  <Button name="decision" value="REJECTED" type="submit" variant="destructive">Reject</Button>
                </form>
              </CardContent>
            </Card>
          );
        })}
        {pendingApprovals.length === 0 && (
          <Card><CardContent className="py-8 text-center text-sm text-muted-foreground">Nothing pending. You're all caught up.</CardContent></Card>
        )}
      </div>
    </div>
  );
}
