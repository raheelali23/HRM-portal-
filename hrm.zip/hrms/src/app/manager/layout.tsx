import { requireRole } from "@/lib/rbac";
import { SidebarNav } from "@/components/sidebar-nav";
import { prisma } from "@/lib/prisma";

const NAV = [
  { href: "/manager", label: "Dashboard", icon: "dashboard" as const },
  { href: "/manager/approvals", label: "Leave Approvals", icon: "approvals" as const },
  { href: "/org-chart", label: "Org Chart", icon: "chart" as const },
];

export default async function ManagerLayout({ children }: { children: React.ReactNode }) {
  const session = await requireRole(["MANAGER", "SUPER_ADMIN"]);
  const employee = session.employeeId
    ? await prisma.employee.findUnique({ where: { id: session.employeeId } })
    : null;
  return (
    <div className="flex">
      <SidebarNav items={NAV} roleLabel="Manager" userName={employee ? `${employee.firstName} ${employee.lastName}` : session.email} />
      <main className="flex-1 p-6">{children}</main>
    </div>
  );
}
