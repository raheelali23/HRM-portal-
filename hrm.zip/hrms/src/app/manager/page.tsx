import { requireRole } from "@/lib/rbac";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { getAllReports } from "@/lib/leave";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { HeadcountBarChart } from "@/components/charts/headcount-bar-chart";

export default async function ManagerDashboard() {
  const session = await requireRole(["MANAGER", "SUPER_ADMIN"]);
  if (!session.employeeId) redirect("/admin");

  const reports = await getAllReports(session.employeeId);
  const reportIds = reports.map((r) => r.id);

  const [pendingCount, teamLeave] = await Promise.all([
    prisma.leaveApproval.count({ where: { approverId: session.employeeId, decision: "PENDING" } }),
    prisma.leaveRequest.findMany({
      where: { employeeId: { in: reportIds } },
      include: { employee: true, leaveType: true },
      orderBy: { createdAt: "desc" },
      take: 10,
    }),
  ]);

  const byDept: Record<string, number> = {};
  for (const r of reports) byDept[r.departmentId] = (byDept[r.departmentId] ?? 0) + 1;
  const departments = await prisma.department.findMany({ where: { id: { in: Object.keys(byDept) } } });
  const chartData = departments.map((d) => ({ name: d.name, count: byDept[d.id] }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Manager Dashboard</h1>
        <p className="text-sm text-muted-foreground">{reports.length} direct/indirect reports</p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Pending Your Approval</CardTitle></CardHeader>
          <CardContent><p className="text-3xl font-semibold">{pendingCount}</p></CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Team Size</CardTitle></CardHeader>
          <CardContent><p className="text-3xl font-semibold">{reports.length}</p></CardContent>
        </Card>
      </div>

      {chartData.length > 0 && (
        <Card>
          <CardHeader><CardTitle>Team by Department</CardTitle></CardHeader>
          <CardContent><HeadcountBarChart data={chartData} /></CardContent>
        </Card>
      )}

      <Card>
        <CardHeader><CardTitle>Recent Team Leave Activity</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          {teamLeave.map((r) => (
            <div key={r.id} className="flex justify-between text-sm">
              <span>{r.employee.firstName} {r.employee.lastName} — {r.leaveType.name}</span>
              <span className="text-muted-foreground">{r.status.replace(/_/g, " ")}</span>
            </div>
          ))}
          {teamLeave.length === 0 && <p className="text-sm text-muted-foreground">No recent activity.</p>}
        </CardContent>
      </Card>
    </div>
  );
}
