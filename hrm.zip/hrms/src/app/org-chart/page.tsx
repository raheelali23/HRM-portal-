import { prisma } from "@/lib/prisma";
import { requireSession } from "@/lib/rbac";
import { OrgChartTree } from "@/components/org-chart-tree";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

// Builds one or more root->leaf trees from a flat employee list (in-memory, no extra queries).
function buildForest(employees: any[]) {
  const byId = new Map(employees.map((e) => [e.id, { ...e, children: [] as any[] }]));
  const roots: any[] = [];
  for (const e of byId.values()) {
    if (e.managerId && byId.has(e.managerId)) {
      byId.get(e.managerId)!.children.push(e);
    } else {
      roots.push(e);
    }
  }
  return roots;
}

export default async function OrgChartPage({ searchParams }: { searchParams: { subsidiary?: string } }) {
  const session = await requireSession();

  const subsidiaries = await prisma.subsidiary.findMany();
  // Super Admin sees a consolidated global chart (or can filter); other roles are confined to their subsidiary.
  let subsidiaryId = searchParams.subsidiary;
  if (session.role !== "SUPER_ADMIN") {
    const employee = await prisma.employee.findUnique({ where: { id: session.employeeId ?? "" } });
    subsidiaryId = employee?.subsidiaryId;
  }

  const employees = await prisma.employee.findMany({
    where: subsidiaryId ? { subsidiaryId } : {},
    include: { designation: true, department: true },
  });
  const forest = buildForest(employees);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-semibold">Organization Chart</h1>
        <p className="text-sm text-muted-foreground">
          {session.role === "SUPER_ADMIN" ? "Consolidated view across the company" : "Your subsidiary's reporting structure"}
        </p>
      </div>

      {session.role === "SUPER_ADMIN" && (
        <form className="flex gap-2" method="get">
          <select name="subsidiary" defaultValue={searchParams.subsidiary} className="h-9 rounded-md border border-border px-2 text-sm">
            <option value="">All subsidiaries (global chart)</option>
            {subsidiaries.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
          <button className="h-9 rounded-md bg-primary px-4 text-sm text-primary-foreground">View</button>
        </form>
      )}

      <Card>
        <CardHeader><CardTitle>Reporting structure</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          {forest.length === 0 && <p className="text-sm text-muted-foreground">No employees to display.</p>}
          {forest.map((root) => (
            <OrgChartTree key={root.id} node={root} />
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
