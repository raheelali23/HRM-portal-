type EmployeeNode = {
  id: string;
  firstName: string;
  lastName: string;
  designation: { title: string };
  department: { name: string };
  children: EmployeeNode[];
};

export function OrgChartTree({ node }: { node: EmployeeNode }) {
  return (
    <ul className="pl-4">
      <li>
        <div className="mb-1 inline-flex flex-col rounded-md border border-border bg-card px-3 py-2 shadow-sm">
          <span className="text-sm font-medium">{node.firstName} {node.lastName}</span>
          <span className="text-xs text-muted-foreground">{node.designation.title} · {node.department.name}</span>
        </div>
        {node.children.length > 0 && (
          <ul className="ml-3 border-l border-dashed border-border pl-4">
            {node.children.map((child) => (
              <li key={child.id} className="mt-2">
                <OrgChartTree node={child} />
              </li>
            ))}
          </ul>
        )}
      </li>
    </ul>
  );
}
