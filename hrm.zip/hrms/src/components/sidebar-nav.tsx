"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard, Users, Building2, GitBranch, CalendarClock,
  CheckSquare, CalendarDays, LogOut,
} from "lucide-react";

export type NavItem = { href: string; label: string; icon: keyof typeof ICONS };

const ICONS = {
  dashboard: LayoutDashboard,
  employees: Users,
  org: Building2,
  chart: GitBranch,
  leave: CalendarClock,
  approvals: CheckSquare,
  calendar: CalendarDays,
};

export function SidebarNav({ items, roleLabel, userName }: { items: NavItem[]; roleLabel: string; userName: string }) {
  const pathname = usePathname();
  return (
    <aside className="flex h-screen w-60 shrink-0 flex-col border-r border-border bg-card">
      <div className="border-b border-border p-4">
        <p className="text-sm font-semibold">HRMS</p>
        <p className="text-xs text-muted-foreground">{roleLabel}</p>
      </div>
      <nav className="flex-1 space-y-1 p-3">
        {items.map((item) => {
          const Icon = ICONS[item.icon];
          const active = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-2 rounded-md px-3 py-2 text-sm transition-colors",
                active ? "bg-primary text-primary-foreground" : "text-foreground hover:bg-secondary"
              )}
            >
              <Icon className="h-4 w-4" />
              {item.label}
            </Link>
          );
        })}
      </nav>
      <div className="border-t border-border p-3">
        <p className="mb-2 truncate text-xs text-muted-foreground">{userName}</p>
        <form action="/api/auth/logout" method="post">
          <button className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm text-muted-foreground hover:bg-secondary">
            <LogOut className="h-4 w-4" /> Log out
          </button>
        </form>
      </div>
    </aside>
  );
}
