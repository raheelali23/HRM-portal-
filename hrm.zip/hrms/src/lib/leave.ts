import "server-only";
import { prisma } from "@/lib/prisma";

/**
 * Core leave-approval state machine.
 *
 * Flow:
 *  1. Employee submits -> status PENDING_MANAGER, one LeaveApproval row (level MANAGER, approver = direct manager).
 *  2. Manager decides:
 *     - REJECTED  -> request REJECTED, stop.
 *     - APPROVED  -> if days > leaveType.escalationDays, escalate to Dept Head (PENDING_DEPT_HEAD),
 *                    else request is APPROVED immediately.
 *  3. Dept Head decides (only reached when escalated):
 *     - REJECTED -> request REJECTED.
 *     - APPROVED -> request APPROVED.
 *  4. HR Manager can, at any point prior to a final state, override the decision (policy exception).
 */

function daysBetweenInclusive(start: Date, end: Date) {
  const ms = end.getTime() - start.getTime();
  return Math.floor(ms / (1000 * 60 * 60 * 24)) + 1;
}

/** Finds the Department Head: the highest manager in the chain who still belongs to the same department. */
async function findDepartmentHead(employeeId: string) {
  const employee = await prisma.employee.findUnique({ where: { id: employeeId } });
  if (!employee) return null;
  let current = employee;
  let head = null;
  while (current.managerId) {
    const manager = await prisma.employee.findUnique({ where: { id: current.managerId } });
    if (!manager) break;
    if (manager.departmentId === employee.departmentId) {
      head = manager;
    } else {
      break; // left the department; the last manager still in-department is the head
    }
    current = manager;
  }
  // Fallback: if nobody above is in the same department, use the direct manager's manager, else direct manager.
  return head ?? (employee.managerId ? await prisma.employee.findUnique({ where: { id: employee.managerId } }) : null);
}

export async function submitLeaveRequest(input: {
  employeeId: string;
  leaveTypeId: string;
  startDate: Date;
  endDate: Date;
  reason: string;
}) {
  const employee = await prisma.employee.findUniqueOrThrow({ where: { id: input.employeeId } });
  if (!employee.managerId) {
    throw new Error("This employee has no manager on record; cannot route a leave request.");
  }
  const days = daysBetweenInclusive(input.startDate, input.endDate);

  const request = await prisma.leaveRequest.create({
    data: {
      employeeId: input.employeeId,
      leaveTypeId: input.leaveTypeId,
      startDate: input.startDate,
      endDate: input.endDate,
      days,
      reason: input.reason,
      status: "PENDING_MANAGER",
      approvals: {
        create: [{ approverId: employee.managerId, level: "MANAGER", decision: "PENDING" }],
      },
    },
    include: { approvals: true },
  });

  return request;
}

export async function decideLeaveApproval(input: {
  leaveRequestId: string;
  approverEmployeeId: string;
  decision: "APPROVED" | "REJECTED";
  comment?: string;
}) {
  const request = await prisma.leaveRequest.findUniqueOrThrow({
    where: { id: input.leaveRequestId },
    include: { leaveType: true, approvals: { orderBy: { createdAt: "asc" } } },
  });

  const pendingApproval = request.approvals.find((a) => a.decision === "PENDING");
  if (!pendingApproval) throw new Error("No pending approval step on this request.");
  if (pendingApproval.approverId !== input.approverEmployeeId) {
    throw new Error("You are not the current approver for this request.");
  }

  await prisma.leaveApproval.update({
    where: { id: pendingApproval.id },
    data: { decision: input.decision, comment: input.comment, decidedAt: new Date() },
  });

  if (input.decision === "REJECTED") {
    await prisma.leaveRequest.update({ where: { id: request.id }, data: { status: "REJECTED" } });
    return { finalStatus: "REJECTED" as const };
  }

  // Approved at this step.
  if (pendingApproval.level === "MANAGER") {
    const needsEscalation = request.days > request.leaveType.escalationDays;
    if (needsEscalation) {
      const deptHead = await findDepartmentHead(request.employeeId);
      if (deptHead) {
        await prisma.leaveApproval.create({
          data: { leaveRequestId: request.id, approverId: deptHead.id, level: "DEPT_HEAD", decision: "PENDING" },
        });
        await prisma.leaveRequest.update({ where: { id: request.id }, data: { status: "PENDING_DEPT_HEAD" } });
        return { finalStatus: "PENDING_DEPT_HEAD" as const };
      }
    }
    await prisma.leaveRequest.update({ where: { id: request.id }, data: { status: "APPROVED" } });
    return { finalStatus: "APPROVED" as const };
  }

  // Dept Head (or HR override) approval finalizes the request.
  await prisma.leaveRequest.update({ where: { id: request.id }, data: { status: "APPROVED" } });
  return { finalStatus: "APPROVED" as const };
}

/** HR Manager exception override: force a final decision regardless of current step. */
export async function hrOverrideLeaveDecision(input: {
  leaveRequestId: string;
  hrEmployeeId: string;
  decision: "APPROVED" | "REJECTED";
  comment: string;
}) {
  const request = await prisma.leaveRequest.findUniqueOrThrow({
    where: { id: input.leaveRequestId },
    include: { approvals: true },
  });

  const pendingApproval = request.approvals.find((a) => a.decision === "PENDING");
  if (pendingApproval) {
    await prisma.leaveApproval.update({
      where: { id: pendingApproval.id },
      data: { decision: "REJECTED", comment: "Superseded by HR override", decidedAt: new Date() },
    });
  }

  await prisma.leaveApproval.create({
    data: {
      leaveRequestId: request.id,
      approverId: input.hrEmployeeId,
      level: "HR",
      decision: input.decision,
      comment: input.comment,
      decidedAt: new Date(),
    },
  });

  await prisma.leaveRequest.update({ where: { id: request.id }, data: { status: input.decision } });
  return { finalStatus: input.decision };
}

/** Full manager chain, closest first — used for escalation display and access checks. */
export async function getManagerChain(employeeId: string) {
  const chain = [];
  let current = await prisma.employee.findUnique({ where: { id: employeeId } });
  while (current?.managerId) {
    const manager = await prisma.employee.findUnique({ where: { id: current.managerId } });
    if (!manager) break;
    chain.push(manager);
    current = manager;
  }
  return chain;
}

/** All direct + indirect reports (BFS) — used for team dashboards. */
export async function getAllReports(employeeId: string) {
  const result = [];
  let frontier = [employeeId];
  while (frontier.length) {
    const direct = await prisma.employee.findMany({ where: { managerId: { in: frontier } } });
    result.push(...direct);
    frontier = direct.map((e) => e.id);
  }
  return result;
}
