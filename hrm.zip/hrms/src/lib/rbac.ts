import "server-only";
import { redirect } from "next/navigation";
import { getSession, type SessionPayload } from "@/lib/auth";
import type { Role } from "@prisma/client";

/** Redirects to /login if unauthenticated, or to their home if role not allowed. */
export async function requireRole(allowed: Role[]): Promise<SessionPayload> {
  const session = await getSession();
  if (!session) redirect("/login");
  if (!allowed.includes(session.role)) redirect(roleHome(session.role));
  return session;
}

export async function requireSession(): Promise<SessionPayload> {
  const session = await getSession();
  if (!session) redirect("/login");
  return session;
}

export function roleHome(role: Role) {
  switch (role) {
    case "SUPER_ADMIN":
      return "/admin";
    case "HR_MANAGER":
      return "/hr";
    case "MANAGER":
      return "/manager";
    case "EMPLOYEE":
    default:
      return "/employee";
  }
}
