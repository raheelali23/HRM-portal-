import { NextResponse, type NextRequest } from "next/server";
import { jwtVerify } from "jose";

const PROTECTED_PREFIXES = ["/admin", "/hr", "/manager", "/employee"];

function getSecretKey() {
  return new TextEncoder().encode(process.env.JWT_SECRET ?? "");
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const isProtected = PROTECTED_PREFIXES.some((p) => pathname.startsWith(p));
  if (!isProtected) return NextResponse.next();

  const token = req.cookies.get("hrms_session")?.value;
  if (!token) return NextResponse.redirect(new URL("/login", req.url));

  try {
    const { payload } = await jwtVerify(token, getSecretKey());
    const role = payload.role as string;

    // Role scoping at the route-group level; page-level checks add finer-grained guards.
    const roleAllowedPrefix: Record<string, string> = {
      SUPER_ADMIN: "/admin",
      HR_MANAGER: "/hr",
      MANAGER: "/manager",
      EMPLOYEE: "/employee",
    };
    // Super Admin may also browse HR/manager/employee areas read-through; others are confined.
    if (role !== "SUPER_ADMIN" && !pathname.startsWith(roleAllowedPrefix[role])) {
      return NextResponse.redirect(new URL(roleAllowedPrefix[role] ?? "/login", req.url));
    }
    return NextResponse.next();
  } catch {
    return NextResponse.redirect(new URL("/login", req.url));
  }
}

export const config = {
  matcher: ["/admin/:path*", "/hr/:path*", "/manager/:path*", "/employee/:path*"],
};
